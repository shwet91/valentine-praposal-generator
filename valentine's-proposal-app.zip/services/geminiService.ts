
import { GoogleGenAI } from "@google/genai";
import { LoveLetterConfig } from "../types";

export const generateLoveLetter = async (config: LoveLetterConfig): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  const prompt = `Write a ${config.tone} Valentine's love letter for ${config.name}. 
  The relationship is described as: ${config.relationship}.
  Keep it under 150 words and make it feel personal and heartfelt.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-latest',
      contents: prompt,
      config: {
        systemInstruction: "You are a professional romantic writer specializing in personalized Valentine's Day messages. Your tone should match the user's requested style perfectly.",
      },
    });

    return response.text || "I couldn't find the words, but my heart is full of love for you. Will you be my Valentine?";
  } catch (error) {
    console.error("Error generating letter:", error);
    return "Something went wrong, but my feelings remain. You are amazing!";
  }
};
