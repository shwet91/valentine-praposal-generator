
import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Proposal from './components/Proposal';
import Features from './components/Features';
import Background from './components/Background';
import LoveLetterModal from './components/LoveLetterModal';

const App: React.FC = () => {
  const [showModal, setShowModal] = useState(false);
  const [accepted, setAccepted] = useState(false);

  const handleAccept = () => {
    setAccepted(true);
    // Add confetti or celebration logic here if needed
  };

  return (
    <div className="min-h-screen relative flex flex-col items-center justify-center p-4 bg-gradient-valentine overflow-x-hidden selection:bg-primary/20">
      <Background />
      
      <Header onSendLove={() => setShowModal(true)} />

      <main className="relative z-10 w-full max-w-5xl flex flex-col items-center">
        {!accepted ? (
          <Proposal onAccept={handleAccept} />
        ) : (
          <div className="text-center animate-in zoom-in duration-500 py-20">
            <div className="relative mb-10">
               <div className="absolute -inset-10 bg-primary/20 rounded-full blur-3xl animate-pulse"></div>
               <img 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuBtG0CFcZsiMWdnBwghghmVs9n6TZNmJ8OMOKvCVZ-ltSM7MEyjaPyuizq755n6hki9swA4NBjd1KHFZNbZ5HxzcKclXH1y67O4si_LX3GiscuN1GR0ARKBNN_IUzyX77rlBqam6sz_Wd807vCUOJKFGNHyafjZA0p1SC2e5ubxLWc0u0RIwQAhvgRptoMIK9_4hxPxR40rD16Zv1yKFZ25HQ-_LGw0PI47k0JNjFnA8Df_b5A1DzoF5iXgxaEalCGrbkHy2yPpa55W" 
                alt="Happy Character"
                className="w-64 h-64 mx-auto rounded-3xl object-contain relative z-10 scale-125"
              />
            </div>
            <h1 className="text-primary text-6xl md:text-8xl font-black mb-6 drop-shadow-sm">Yay! ❤️</h1>
            <p className="text-slate-600 text-2xl font-bold">I knew you'd say yes! I'm so happy! 🥰</p>
            <button 
              onClick={() => setAccepted(false)}
              className="mt-10 text-primary/60 font-bold hover:text-primary transition-colors flex items-center gap-2 mx-auto"
            >
              <span className="material-symbols-outlined">restart_alt</span> See proposal again
            </button>
          </div>
        )}

        <Features />
      </main>

      <footer className="fixed bottom-6 text-center z-10 mt-10 md:mt-0">
        <p className="text-[#8a606b] text-sm font-extrabold tracking-widest uppercase opacity-70">
          MADE WITH <span className="text-primary mx-1">❤</span> FOR YOU
        </p>
      </footer>

      <LoveLetterModal isOpen={showModal} onClose={() => setShowModal(false)} />
    </div>
  );
};

export default App;
