
import React from 'react';
import { Feature } from '../types';

const features: Feature[] = [
  { id: '1', icon: 'favorite', title: "You're Kind", description: "Always helping others" },
  { id: '2', icon: 'sentiment_very_satisfied', title: "You're Funny", description: "You make me laugh daily" },
  { id: '3', icon: 'auto_awesome', title: "You're Cute", description: "Especially when you smile" },
  { id: '4', icon: 'star', title: "You're You", description: "And that's the best part" },
];

const Features: React.FC = () => {
  return (
    <div className="w-full max-w-4xl grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 mt-12 animate-in slide-in-from-bottom-8 duration-1000">
      {features.map((f, i) => (
        <div 
          key={f.id} 
          className="group flex flex-col items-center justify-center gap-3 rounded-[2rem] border-2 border-dashed border-primary/20 bg-white/60 hover:bg-white hover:border-primary/40 p-6 md:p-8 text-center backdrop-blur-sm transition-all duration-300 hover:scale-105"
          style={{ animationDelay: `${i * 100}ms` }}
        >
          <div className="text-primary p-3 rounded-full bg-primary/5 group-hover:bg-primary group-hover:text-white transition-colors duration-300">
            <span className="material-symbols-outlined text-4xl">{f.icon}</span>
          </div>
          <div>
            <h3 className="text-[#181113] text-lg font-black">{f.title}</h3>
            <p className="text-[#8a606b] text-xs mt-1 font-bold opacity-70 group-hover:opacity-100">{f.description}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Features;
