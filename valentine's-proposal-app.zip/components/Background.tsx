
import React from 'react';

const Background: React.FC = () => {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      <div className="absolute top-[10%] left-[5%] text-primary/10 animate-float" style={{ animationDelay: '0s' }}>
        <span className="material-symbols-outlined text-9xl">cloud</span>
      </div>
      <div className="absolute top-[40%] right-[10%] text-primary/10 animate-float" style={{ animationDelay: '2s' }}>
        <span className="material-symbols-outlined text-9xl">cloud</span>
      </div>
      <div className="absolute bottom-[20%] left-[15%] text-primary/20 animate-float" style={{ animationDelay: '1s' }}>
        <span className="material-symbols-outlined text-6xl">favorite</span>
      </div>
      <div className="absolute top-[15%] right-[25%] text-primary/15 animate-float" style={{ animationDelay: '3s' }}>
        <span className="material-symbols-outlined text-4xl">favorite</span>
      </div>
      <div className="absolute bottom-[40%] right-[30%] text-primary/10 animate-float" style={{ animationDelay: '4s' }}>
        <span className="material-symbols-outlined text-8xl">auto_awesome</span>
      </div>
      <div className="absolute top-1/2 left-10 text-primary/5 animate-pulse-slow">
        <span className="material-symbols-outlined text-7xl">favorite</span>
      </div>
      
      {/* Corner Graphic */}
      <div className="absolute -bottom-10 -right-10 opacity-20 transform -rotate-12">
        <span className="material-symbols-outlined text-[300px] text-primary">favorite</span>
      </div>
    </div>
  );
};

export default Background;
