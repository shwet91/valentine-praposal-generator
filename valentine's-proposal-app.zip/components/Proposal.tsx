
import React, { useState } from 'react';

interface Props {
  onAccept: () => void;
}

const Proposal: React.FC<Props> = ({ onAccept }) => {
  const [noPosition, setNoPosition] = useState({ x: 0, y: 0 });
  const [noScale, setNoScale] = useState(1);
  const [noCount, setNoCount] = useState(0);

  const noPhrases = [
    "No 😢",
    "Are you sure? 🤨",
    "Really sure? 🥺",
    "Think again... 🧐",
    "Last chance! 😭",
    "Surely not? 😱",
    "You're heartless! 💔",
    "I'll be sad... 😞",
    "Very very sad... 😭",
    "Okay, fine... 😡",
    "Wait, no! Please! 🙏",
  ];

  const handleNoHover = () => {
    if (noCount > 3) {
      const x = (Math.random() - 0.5) * 300;
      const y = (Math.random() - 0.5) * 300;
      setNoPosition({ x, y });
    }
  };

  const handleNoClick = () => {
    setNoCount(prev => prev + 1);
    setNoScale(prev => Math.max(0.2, prev - 0.1));
    
    // Teleport on click too
    const x = (Math.random() - 0.5) * 400;
    const y = (Math.random() - 0.5) * 400;
    setNoPosition({ x, y });
  };

  return (
    <div className="flex flex-col items-center text-center mt-12 mb-20 animate-in fade-in slide-in-from-top-4 duration-700">
      {/* Illustration Area */}
      <div className="mb-10 relative group">
        <div className="absolute -inset-4 bg-primary/10 rounded-full blur-3xl opacity-50 group-hover:opacity-100 transition-opacity duration-500"></div>
        <div className="relative bg-white p-6 rounded-[2.5rem] border-4 border-dashed border-primary/20 shadow-inner">
          <img 
            alt="Cute Character" 
            className="w-48 h-48 md:w-64 md:h-64 object-contain rounded-2xl hover:scale-105 transition-transform duration-500" 
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuBtG0CFcZsiMWdnBwghghmVs9n6TZNmJ8OMOKvCVZ-ltSM7MEyjaPyuizq755n6hki9swA4NBjd1KHFZNbZ5HxzcKclXH1y67O4si_LX3GiscuN1GR0ARKBNN_IUzyX77rlBqam6sz_Wd807vCUOJKFGNHyafjZA0p1SC2e5ubxLWc0u0RIwQAhvgRptoMIK9_4hxPxR40rD16Zv1yKFZ25HQ-_LGw0PI47k0JNjFnA8Df_b5A1DzoF5iXgxaEalCGrbkHy2yPpa55W" 
          />
        </div>
      </div>

      {/* Question Card */}
      <div className="bg-white/90 backdrop-blur-md px-10 py-12 md:px-20 md:py-16 rounded-[2.5rem] shadow-2xl shadow-primary/5 border border-primary/5 mb-12 max-w-2xl relative">
        <h1 className="text-primary text-4xl md:text-6xl font-black leading-tight tracking-tight mb-6">
          Will you be my Valentine?
        </h1>
        <p className="text-[#8a606b] text-base md:text-xl font-medium max-w-sm mx-auto">
          I promise it'll be fun and full of treats! Think carefully... 😉
        </p>
      </div>

      {/* Buttons Container */}
      <div className="flex flex-col sm:flex-row gap-6 items-center min-h-[100px]">
        <button 
          onClick={onAccept}
          style={{ transform: `scale(${1 + noCount * 0.1})` }}
          className="group relative flex min-w-[200px] cursor-pointer items-center justify-center overflow-hidden rounded-full h-16 md:h-20 px-12 bg-primary text-white text-2xl font-black shadow-2xl shadow-primary/40 hover:scale-[1.05] active:scale-95 transition-all z-20"
        >
          <span className="flex items-center gap-2">Yes 💖</span>
          <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
        </button>

        <button 
          onMouseEnter={handleNoHover}
          onClick={handleNoClick}
          style={{ 
            transform: `translate(${noPosition.x}px, ${noPosition.y}px) scale(${noScale})`,
            transition: 'all 0.2s cubic-bezier(0.34, 1.56, 0.64, 1)'
          }}
          className="min-w-[160px] cursor-pointer items-center justify-center rounded-full h-14 md:h-16 px-10 bg-primary/10 text-primary text-lg font-bold hover:bg-primary/20 border-2 border-primary/5 whitespace-nowrap"
        >
          {noPhrases[Math.min(noCount, noPhrases.length - 1)]}
        </button>
      </div>
    </div>
  );
};

export default Proposal;
